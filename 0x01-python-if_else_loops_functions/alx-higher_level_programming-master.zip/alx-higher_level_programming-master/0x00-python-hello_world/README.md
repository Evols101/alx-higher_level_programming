Basics in Python
