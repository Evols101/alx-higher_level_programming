This directory is all about if,else, looping and function of pythron programming lang.
